﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HomelessStudentBE;
using System.Data.Entity;
using System.ComponentModel;

namespace BLFrontend
{
    public interface IBLFrontend
    {
        BindingList<Owner> ListOfOwners();
        Owner GetOwner(string username);
        bool NewOwner(Owner OwnerToAdd);
        bool UpdateOwner(Owner OwnerToUpdate);
        bool DeleteOwner(Owner OwnerToDelete);

        BindingList<Agent> ListOfAgents();
        bool NewAgent(Agent AgentToAdd);
        bool UpdateAgent(Agent AgentToUpdate);
        bool DeleteAgent(Agent AgentToDelete);

        bool NewRenter(Renter RenterToAdd);
        bool UpdateRenter(Renter RenterToUpdate);
        bool DeleteRenter(Renter RenterToDelete);

        BindingList<Apartment> ListOfApartments();
        bool NewApartment(Apartment ApartmentToAdd);
        bool UpdateApartment(Apartment ApartmentToUpdate);
        bool DeleteApartment(Apartment ApartmentToDelete);

        BindingList<City> ListOfCities();
        BindingList<ApartmentType> ListOfApartmentTypes();


        List<Apartment> SearchApartments(int CityID, int Agency, int ApartmentTypeID, float FromRooms, float ToRooms,
            int FromPrice, int ToPrice, int FromFloor, int ToFloor);
       

    }
}
