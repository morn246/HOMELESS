﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HomelessStudentBE;
using System.Data.Entity;
using BLFrontend.HomelessStudentWSRef;
using System.ComponentModel;

namespace BLFrontend
{
    [DataObject]
    public class Frontend : IBLFrontend
    {
        public BindingList<Owner> ListOfOwners()
        {
            return new BindingList<Owner>(new BLBackendClient().GetOwners());
        }

        public Owner GetOwner(string username)
        {
            return new BLBackendClient().GetOwner(username);
        }

        public bool NewOwner(Owner OwnerToAdd)
        {
            return new BLBackendClient().AddOwner(OwnerToAdd);
        }

        public bool UpdateOwner(Owner OwnerToUpdate)
        {
            return new BLBackendClient().UpdateOwner(OwnerToUpdate);
        }

        public bool DeleteOwner(Owner OwnerToDelete)
        {
            return new BLBackendClient().DeleteOwner(OwnerToDelete);
        }


        public BindingList<Agent> ListOfAgents()
        {
            return new BindingList<Agent>(new BLBackendClient().GetAgents());
        }

        public bool NewAgent(Agent AgentToAdd)
        {
            return new BLBackendClient().AddAgent(AgentToAdd);
        }

        public bool UpdateAgent(Agent AgentToUpdate)
        {
            return new BLBackendClient().UpdateAgent(AgentToUpdate);
        }

        public bool DeleteAgent(Agent AgentToDelete)
        {
            return new BLBackendClient().DeleteAgent(AgentToDelete);
        }

        public bool NewRenter(Renter RenterToAdd)
        {
            return new BLBackendClient().AddRenter(RenterToAdd);
        }

        public bool UpdateRenter(Renter RenterToUpdate)
        {
            return new BLBackendClient().UpdateRenter(RenterToUpdate);
        }

        public bool DeleteRenter(Renter RenterToDelete)
        {
            return new BLBackendClient().DeleteRenter(RenterToDelete);
        }

        public BindingList<Apartment> ListOfApartments()
        {
            return new BindingList<Apartment>(new BLBackendClient().GetApartments());
        }

        public bool NewApartment(Apartment ApartmentToAdd)
        {
            return new BLBackendClient().AddApartment(ApartmentToAdd);
        }

        public bool UpdateApartment(Apartment ApartmentToUpdate)
        {
            return new BLBackendClient().UpdateApartment(ApartmentToUpdate);
        }

        public bool DeleteApartment(Apartment ApartmentToDelete)
        {
            return new BLBackendClient().DeleteApartment(ApartmentToDelete);
        }


        public BindingList<City> ListOfCities()
        {
            return new BindingList<City>(new BLBackendClient().GetCities());
        }

        public BindingList<ApartmentType> ListOfApartmentTypes()
        {
            return new BindingList<ApartmentType>(new BLBackendClient().GetApartmentTypes());
        }

        public List<Apartment> SearchApartments(int CityID, int Agency, int ApartmentTypeID, float FromRooms, float ToRooms,
            int FromPrice, int ToPrice, int FromFloor, int ToFloor)
        {
            return new BLBackendClient().SearchApartments(CityID, Agency, ApartmentTypeID, FromRooms, ToRooms, FromPrice, ToPrice, FromFloor, ToFloor);
            
        }




    }
}
