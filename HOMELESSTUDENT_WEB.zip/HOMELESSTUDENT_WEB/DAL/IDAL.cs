﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HomelessStudentBE;
using System.Data.Entity;

namespace DAL
{
    interface IDAL
    {
        DbSet<Owner> ReadOwners();
        bool CreateOwner(Owner OwnerToCreate);
        bool UpdateOwner(Owner OwnerToUpdate);
        bool DeleteOwner(Owner OwnerToDelete);

        DbSet<Agent> ReadAgents();
        bool CreateAgent(Agent AgentToCreate);
        bool UpdateAgent(Agent AgentToUpdate);
        bool DeleteAgent(Agent AgentToDelete);

        bool CreateRenter(Renter RenterToCreate);
        bool UpdateRenter(Renter RenterToUpdate);
        bool DeleteRenter(Renter RenterToDelete);

        DbSet<Apartment> ReadApartments();
        bool CreateApartment(Apartment ApartmentToCreate);
        bool UpdateApartment(Apartment ApartmentToUpdate);
        bool DeleteApartment(Apartment ApartmentToDelete);

        DbSet<City> ReadCities();
        DbSet<ApartmentType> ReadApartmentTypes();
        


    }
}
