﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HomelessStudentBE;
using System.Data.Entity;

namespace DAL
{
    public class DataLayer : IDAL
    {
        HomelessStudentDBEntities entities = new HomelessStudentDBEntities();

        public DataLayer()
        {
            entities.Configuration.ProxyCreationEnabled = false;            
        }

        public DbSet<Owner> ReadOwners()
        {
            return entities.Owners;
        }

        public bool CreateOwner(Owner OwnerToCreate)
        {
            var context = entities;            
            context.Owners.Add(OwnerToCreate);
            return context.SaveChanges() > 0;
        }

        public bool UpdateOwner(Owner OwnerToUpdate)
        {
            var context = entities;
            Owner toUpdate = context.Owners.FirstOrDefault<Owner>(p => p.Username == OwnerToUpdate.Username);
            if (toUpdate != null)
            {
                toUpdate.Name = OwnerToUpdate.Name;
                //toUpdate.Username = OwnerToUpdate.Username;
                toUpdate.Password = OwnerToUpdate.Password;
                toUpdate.Phone = OwnerToUpdate.Phone;
                toUpdate.Mail = OwnerToUpdate.Mail;
                toUpdate.Description = OwnerToUpdate.Description;             
                return context.SaveChanges() > 0;
            }
            else
                return false;
        }

        public bool DeleteOwner(Owner OwnerToDelete)
        {
            var context = entities;
            Owner toDelete = context.Owners.FirstOrDefault<Owner>(p => p.OwnerID == OwnerToDelete.OwnerID);
            if (toDelete != null)
            {
                context.Owners.Remove(toDelete);
                return context.SaveChanges() > 0;
            }
            else
                return false;
        }


        public DbSet<Agent> ReadAgents()
        {
            return entities.Agents;
        }

        public bool CreateAgent(Agent AgentToCreate)
        {
            var context = entities;
            context.Agents.Add(AgentToCreate);
            return context.SaveChanges() > 0;
        }

        public bool UpdateAgent(Agent AgentToUpdate)
        {
            var context = entities;
            Agent toUpdate = context.Agents.FirstOrDefault<Agent>(p => p.AgentID == AgentToUpdate.AgentID);
            if (toUpdate != null)
            {
                toUpdate.Name = AgentToUpdate.Name;
                toUpdate.Username = AgentToUpdate.Username;
                toUpdate.Password = AgentToUpdate.Password;
                toUpdate.Phone = AgentToUpdate.Phone;
                toUpdate.Mail = AgentToUpdate.Mail;
                toUpdate.Description = AgentToUpdate.Description;
                toUpdate.AgencyPercentage = AgentToUpdate.AgencyPercentage;
                return context.SaveChanges() > 0;
            }
            else
                return false;
        }

        public bool DeleteAgent(Agent AgentToDelete)
        {
            var context = entities;
            Agent toDelete = context.Agents.FirstOrDefault<Agent>(p => p.AgentID == AgentToDelete.AgentID);
            if (toDelete != null)
            {
                context.Agents.Remove(toDelete);
                return context.SaveChanges() > 0;
            }
            else
                return false;
        }

        public bool CreateRenter(Renter RenterToCreate)
        {
            var context = entities;
            context.Renters.Add(RenterToCreate);
            return context.SaveChanges() > 0;
        }

        public bool UpdateRenter(Renter RenterToUpdate)
        {
            var context = entities;
            Renter toUpdate = context.Renters.FirstOrDefault<Renter>(p => p.RenterID == RenterToUpdate.RenterID);
            if (toUpdate != null)
            {
                toUpdate.Name = RenterToUpdate.Name;
                toUpdate.Username = RenterToUpdate.Username;
                toUpdate.Password = RenterToUpdate.Password;
                toUpdate.Phone = RenterToUpdate.Phone;
                toUpdate.Mail = RenterToUpdate.Mail;
                toUpdate.Description = RenterToUpdate.Description;
                toUpdate.Religious = RenterToUpdate.Religious;
                toUpdate.CollegeName = RenterToUpdate.CollegeName;
                toUpdate.Age = RenterToUpdate.Age;
                return context.SaveChanges() > 0;
            }
            else
                return false;
        }

        public bool DeleteRenter(Renter RenterToDelete)
        {
            var context = entities;
            Renter toDelete = context.Renters.FirstOrDefault<Renter>(p => p.RenterID == RenterToDelete.RenterID);
            if (toDelete != null)
            {
                context.Renters.Remove(toDelete);
                return context.SaveChanges() > 0;
            }
            else
                return false;
        }

        public DbSet<Apartment> ReadApartments()
        {
            return entities.Apartments;
        }

        public bool CreateApartment(Apartment ApartmentToCreate)
        {
            var context = entities;
            context.Apartments.Add(ApartmentToCreate);
            return context.SaveChanges() > 0;
        }

        public bool UpdateApartment(Apartment ApartmentToUpdate)
        {
            var context = entities;
            Apartment toUpdate = context.Apartments.FirstOrDefault<Apartment>(p => p.ApartmentID == ApartmentToUpdate.ApartmentID);
            if (toUpdate != null)
            {
                toUpdate.Address = ApartmentToUpdate.Address;
                toUpdate.OwnerID = ApartmentToUpdate.OwnerID;
                //toUpdate.AgentID = ApartmentToUpdate.AgentID;
                //toUpdate.ApartmentTypeID = ApartmentToUpdate.ApartmentTypeID;
                //toUpdate.Floor = ApartmentToUpdate.Floor;
                //toUpdate.Rooms = ApartmentToUpdate.Rooms;
                //toUpdate.Agency = ApartmentToUpdate.Agency;
                //toUpdate.Immediately = ApartmentToUpdate.Immediately;
                //toUpdate.DateOfEntrance = ApartmentToUpdate.DateOfEntrance;
                //toUpdate.Price = ApartmentToUpdate.Price;
                //toUpdate.Description = ApartmentToUpdate.Description;
                //toUpdate.CityID = ApartmentToUpdate.CityID;
                return context.SaveChanges() > 0;
            }
            else
                return false;
        }

        public bool DeleteApartment(Apartment ApartmentToDelete)
        {
            var context = entities;
            Apartment toDelete = context.Apartments.FirstOrDefault<Apartment>(p => p.ApartmentID == ApartmentToDelete.ApartmentID);
            if (toDelete != null)
            {
                context.Apartments.Remove(toDelete);
                return context.SaveChanges() > 0;
            }
            else
                return false;
        }

        public DbSet<City> ReadCities()
        {
            return entities.Cities;
        }

        public DbSet<ApartmentType> ReadApartmentTypes()
        {
            return entities.ApartmentTypes;
        }
    }
}
