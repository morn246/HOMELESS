﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HomelessStudentBE;
using System.ServiceModel;

namespace BLBackend
{
    [ServiceContract]
    interface IBLBackend
    {
        [OperationContract]
        List<Owner> GetOwners();
        [OperationContract]
        Owner GetOwner(string username);
        [OperationContract]
        bool AddOwner(Owner OwnerToAdd);
        [OperationContract]
        bool UpdateOwner(Owner OwnerToUpdate);
        [OperationContract]
        bool DeleteOwner(Owner OwnerToDelete);

        [OperationContract]
        List<Agent> GetAgents();
        [OperationContract]
        bool AddAgent(Agent AgentToAdd);
        [OperationContract]
        bool UpdateAgent(Agent AgentToUpdate);
        [OperationContract]
        bool DeleteAgent(Agent AgentToDelete);

        [OperationContract]
        bool AddRenter(Renter RenterToAdd);
        [OperationContract]
        bool UpdateRenter(Renter RenterToUpdate);
        [OperationContract]
        bool DeleteRenter(Renter RenterToDelete);

        [OperationContract]
        List<Apartment> GetApartments();
        [OperationContract]
        bool AddApartment(Apartment ApartmentToAdd);
        [OperationContract]
        bool UpdateApartment(Apartment ApartmentToUpdate);
        [OperationContract]
        bool DeleteApartment(Apartment ApartmentToDelete);

        [OperationContract]
        List<City> GetCities();

        [OperationContract]
        List<ApartmentType> GetApartmentTypes();

        [OperationContract]
        List<Apartment> SearchApartments(int CityID, int Agency, int ApartmentTypeID, float FromRooms, float ToRooms, int FromPrice, int ToPrice, int FromFloor, int ToFloor);
    }
}
