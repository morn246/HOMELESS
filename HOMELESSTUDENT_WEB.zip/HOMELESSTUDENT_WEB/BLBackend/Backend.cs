﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HomelessStudentBE;
using System.Data.Entity;
using DAL;

namespace BLBackend
{
    class Backend : IBLBackend
    {
        public List<Owner> GetOwners()
        {
            return new DataLayer().ReadOwners().ToList<Owner>();
        }

        public Owner GetOwner(string username)
        {
            //DataLayer dal = new DataLayer();
            //var ls = from d in dal.ReadOwners()
            //        where (d.Username == username && d.Password == password)
            //        select d;
            //List<Owner> list = ls.ToList<Owner>();
            //return list.FirstOrDefault();

            DataLayer dal = new DataLayer();
            var ls = from d in dal.ReadOwners()
                     where d.Username == username
                     select d;
            List<Owner> list = ls.ToList<Owner>();
            return list.FirstOrDefault();


        }

        public bool AddOwner(Owner OwnerToAdd)
        {
            return new DataLayer().CreateOwner(OwnerToAdd);
        }

        public bool UpdateOwner(Owner OwnerToUpdate)
        {
            return new DataLayer().UpdateOwner(OwnerToUpdate);
        }

        public bool DeleteOwner(Owner OwnerToDelete)
        {
            return new DataLayer().DeleteOwner(OwnerToDelete);
        }


        public List<Agent> GetAgents()
        {
            return new DataLayer().ReadAgents().ToList<Agent>();
        }

        public bool AddAgent(Agent AgentToAdd)
        {
            return new DataLayer().CreateAgent(AgentToAdd);
        }

        public bool UpdateAgent(Agent AgentToUpdate)
        {
            return new DataLayer().UpdateAgent(AgentToUpdate);
        }

        public bool DeleteAgent(Agent AgentToDelete)
        {
            return new DataLayer().DeleteAgent(AgentToDelete);
        }

        public bool AddRenter(Renter RenterToAdd)
        {
            return new DataLayer().CreateRenter(RenterToAdd);
        }

        public bool UpdateRenter(Renter RenterToUpdate)
        {
            return new DataLayer().UpdateRenter(RenterToUpdate);
        }

        public bool DeleteRenter(Renter RenterToDelete)
        {
            return new DataLayer().DeleteRenter(RenterToDelete);
        }

        public List<Apartment> GetApartments()
        {
            return new DataLayer().ReadApartments().ToList<Apartment>();
        }

        public bool AddApartment(Apartment ApartmentToAdd)
        {
            return new DataLayer().CreateApartment(ApartmentToAdd);
        }

        public bool UpdateApartment(Apartment ApartmentToUpdate)
        {
            return new DataLayer().UpdateApartment(ApartmentToUpdate);
        }

        public bool DeleteApartment(Apartment ApartmentToDelete)
        {
            return new DataLayer().DeleteApartment(ApartmentToDelete);
        }


        public List<City> GetCities()
        {
            return new DataLayer().ReadCities().ToList<City>();
        }

        public List<ApartmentType> GetApartmentTypes()
        {
            return new DataLayer().ReadApartmentTypes().ToList<ApartmentType>();
        }

        public List<Apartment> SearchApartments(int CityID, int Agency, int ApartmentTypeID, float FromRooms, 
            float ToRooms, int FromPrice, int ToPrice, int FromFloor, int ToFloor)
        {
            DataLayer dal = new DataLayer();
            var ls = from a in dal.ReadApartments()
                     where (a.City.CityID == CityID || CityID == -1)
                     && ((Agency == 0 && a.AgentID == null) || (Agency == 1 && a.OwnerID == null) || (Agency == -1))
                     && (a.ApartmentType.ApartmentTypeID == ApartmentTypeID || ApartmentTypeID == -1)
                     && (((a.Rooms >= FromRooms) && (a.Rooms <= ToRooms)) || ((FromRooms == -1) && (a.Rooms <= ToRooms))
                        || ((a.Rooms >= FromRooms) && (ToRooms == -1)) || ((FromRooms == -1) && (ToRooms == -1)))
                     && (((a.Price >= FromPrice) && (a.Price <= ToPrice)) || ((FromPrice == -1) && (a.Price <= ToPrice))
                        || ((a.Price >= FromPrice) && (ToPrice == -1)) || (FromPrice == -1) && (ToPrice == -1))
                     && (((a.Floor >= FromFloor) && (a.Floor <= ToFloor)) || ((FromFloor == -1) && (a.Floor <= ToFloor))
                        || ((a.Floor >= FromFloor) && (ToFloor == -1)) || ((FromFloor == -1) && (ToFloor == -1)))

                     select a;

            List<Apartment> list = ls.ToList<Apartment>();
            return list;

            //DataLayer dal = new DataLayer();
            //var q = (from t1 in dal.ReadApartments()

            //         join t2 in dal.ReadAgents() on t1.AgentID equals t2.AgentID
            //         join t3 in dal.ReadApartmentTypes() on t1.apartmentTypeID equals t3.ApartmentTypeID
            //         join t4 in dal.ReadCities() on t1.CityID equals t4.CityID

            //         select new
            //         {
            //             t1.ApartmentID,
            //             t1.Address,
            //             t2.Name,
            //             t2.Phone,
            //             t2.Mail,
            //             t3.Type,
            //             t1.Floor,
            //             t1.Rooms,
            //             t1.AgencyFees,
            //             t1.Immediately,
            //             t1.DateOfEntrance,
            //             t1.Price,
            //             t1.Description,
            //             t1.Image,
            //             t4.CityName


            //         });//.ToList();
            //List<object> list = q.ToList<object>();
            //return list;
        }





     
    }
}
