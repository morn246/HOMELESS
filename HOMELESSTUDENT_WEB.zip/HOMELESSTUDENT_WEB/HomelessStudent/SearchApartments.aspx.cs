﻿using BLFrontend;
using HomelessStudentBE;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HomelessStudent
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        IBLFrontend frontend = new BLFrontend.Frontend();
       
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
               

                List<City> allCities = frontend.ListOfCities().ToList<City>();
                cityDropDownList.DataSource = allCities;
                cityDropDownList.DataTextField = "CityName"; //תציג למשתמש את השם של העיר
                cityDropDownList.DataValueField = "CityID"; //אבל תעבוד לפי המספר של העיר

                //cityDropDownList.DataSource = from c in frontend.ListOfCities()
                //                              select c.Name;

                cityDropDownList.DataBind(); //לקשר את הנתונים כדי שנראה משהו על המסך

                List<ApartmentType> allApartmentTypes = frontend.ListOfApartmentTypes().ToList<ApartmentType>();
                apartmentTypeDropDownList.DataSource = allApartmentTypes;
                apartmentTypeDropDownList.DataTextField = "Type";
                apartmentTypeDropDownList.DataValueField = "ApartmentTypeID"; 
                apartmentTypeDropDownList.DataBind();

                List<float> ls = new List<float>();
                for (float i = 1; i < 11; )
                {
                    ls.Add(i);
                    i = (float)(i + 0.5);
                }
                fromRoomsDropDownList.DataSource = ls;
                fromRoomsDropDownList.DataBind();
                toRoomsDropDownList.DataSource = ls;
                toRoomsDropDownList.DataBind();

                fromFloorDropDownList.DataSource = Enumerable.Range(0, 51);
                fromFloorDropDownList.DataBind();
                toFloorDropDownList.DataSource = Enumerable.Range(0, 51);
                toFloorDropDownList.DataBind();

                fromPriceTextBox.Attributes["onfocus"] = "return fromPriceTextFocus();";
                fromPriceTextBox.Attributes["onblur"] = "return fromPriceTextSearch();";
                toPriceTextBox.Attributes["onfocus"] = "return toPriceTextFocus();";
                toPriceTextBox.Attributes["onblur"] = "return toPriceTextSearch();";   
                
            }
            
        }

        protected void searchButton_Click(object sender, EventArgs e)
        {
            int CityID;
            if (cityDropDownList.SelectedValue == "הכל")
                CityID = -1;
            else
                CityID = Convert.ToInt32(cityDropDownList.SelectedValue);//מקבלים את מספר העיר 

            int Agency;
            if (agencyDropDownList.SelectedValue == "לא")
                Agency = 0;
            else if (agencyDropDownList.SelectedValue == "כן")
                Agency = 1;
            else 
                Agency = -1;

            int ApartmentTypeID;
            if (apartmentTypeDropDownList.SelectedValue == "הכל")
                ApartmentTypeID = -1;
            else
                ApartmentTypeID = Convert.ToInt32(apartmentTypeDropDownList.SelectedValue);

            float FromRooms;
            if (fromRoomsDropDownList.SelectedValue == "")
                FromRooms = -1;
            else
                FromRooms = float.Parse(fromRoomsDropDownList.SelectedValue);

            float ToRooms;
            if (toRoomsDropDownList.SelectedValue == "")
                ToRooms = -1;
            else
                ToRooms = float.Parse(toRoomsDropDownList.SelectedValue);

            int FromPrice;
            if (fromPriceTextBox.Text == "הכל")
                FromPrice = -1;
            else
                FromPrice = Convert.ToInt32(fromPriceTextBox.Text);

            int ToPrice;
            if (toPriceTextBox.Text == "הכל")
                ToPrice = -1;
            else
                ToPrice = Convert.ToInt32(toPriceTextBox.Text);

            int FromFloor;
            if (fromFloorDropDownList.SelectedValue == "")
                FromFloor = -1;
            else
                FromFloor = Convert.ToInt32(fromFloorDropDownList.SelectedValue);
            
            int ToFloor;
            if (toFloorDropDownList.SelectedValue == "")
                ToFloor = -1;
            else
                ToFloor = Convert.ToInt32(toFloorDropDownList.SelectedValue);

            ListView1.DataSourceID = null; //כדי לאפס את מקור המידע שלא יהיה מהOBJECTDATASOURCE
            ListView1.DataSource = frontend.SearchApartments(CityID, Agency, ApartmentTypeID, FromRooms, ToRooms, FromPrice, ToPrice, FromFloor, ToFloor);
            ListView1.DataBind(); //לקשר את הנתונים כדי שנראה משהו על המסך
        }

        protected void FavouriteCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            searchButton.Text = "fdgdfg";
            if (((CheckBox)sender).Checked)
            {
                searchButton.Text = "fdgdfg";
            }
        }

       
      

      

     

    }
}