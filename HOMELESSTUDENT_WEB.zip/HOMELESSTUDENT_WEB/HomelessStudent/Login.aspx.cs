﻿using BLFrontend;
using HomelessStudentBE;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;

namespace HomelessStudent
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        IBLFrontend frontend = new BLFrontend.Frontend();
        

        protected void Page_Load(object sender, EventArgs e)
        {
            
        }        

        protected void CreateUserWizard1_CreatedUser(object sender, EventArgs e)
        {
            if (((CheckBox)CreateUserWizardStep1.ContentTemplateContainer.FindControl("RenterCB")).Checked)
            {
                Session["userType"] = "renter";

                Session["username"] = ((TextBox)CreateUserWizardStep1.ContentTemplateContainer.FindControl("UserName")).Text;
                Session["name"] = ((TextBox)CreateUserWizardStep1.ContentTemplateContainer.FindControl("Name")).Text;
                Session["password"] = ((TextBox)CreateUserWizardStep1.ContentTemplateContainer.FindControl("Password")).Text;
                Session["phone"] = ((TextBox)CreateUserWizardStep1.ContentTemplateContainer.FindControl("Phone")).Text;
                Session["mail"] = ((TextBox)CreateUserWizardStep1.ContentTemplateContainer.FindControl("Email")).Text;
                Session["description"] = ((TextBox)CreateUserWizardStep1.ContentTemplateContainer.FindControl("Description")).Text;

            }

            

            if (((CheckBox)CreateUserWizardStep1.ContentTemplateContainer.FindControl("OwnerCB")).Checked)
            {
                Session["userType"] = "owner";

                Owner owner = new Owner();
                
                owner.Username = ((TextBox)CreateUserWizardStep1.ContentTemplateContainer.FindControl("UserName")).Text;
                owner.Name = ((TextBox)CreateUserWizardStep1.ContentTemplateContainer.FindControl("Name")).Text;
                owner.Password = ((TextBox)CreateUserWizardStep1.ContentTemplateContainer.FindControl("Password")).Text;
                owner.Phone = ((TextBox)CreateUserWizardStep1.ContentTemplateContainer.FindControl("Phone")).Text;
                owner.Mail = ((TextBox)CreateUserWizardStep1.ContentTemplateContainer.FindControl("Email")).Text;
                owner.Description = ((TextBox)CreateUserWizardStep1.ContentTemplateContainer.FindControl("Description")).Text;

                frontend.NewOwner(owner);

                if (!Roles.RoleExists("OwnerRole"))
                {
                    Roles.CreateRole("OwnerRole");
                }
                Roles.AddUserToRole(owner.Username, "OwnerRole");

                //In order to skip RenterStep
                CreateUserWizard1.WizardSteps.Remove(CreateUserWizard1.WizardSteps[1]);
                  
            }

            

           
        }

        protected void CreateUserWizard1_ContinueButtonClick(object sender, EventArgs e)
        {
            string username=((TextBox)CreateUserWizardStep1.ContentTemplateContainer.FindControl("UserName")).Text;
            //if (((CheckBox)CreateUserWizardStep1.ContentTemplateContainer.FindControl("RenterCB")).Checked)
            if (Roles.IsUserInRole(username, "RenterRole"))
            {
                CreateUserWizard1.ContinueDestinationPageUrl = "~/RenterPage.aspx";
            }
            //else if (((CheckBox)CreateUserWizardStep1.ContentTemplateContainer.FindControl("OwnerCB")).Checked)
            else if (Roles.IsUserInRole(username, "OwnerRole"))
            {
                CreateUserWizard1.ContinueDestinationPageUrl = "~/OwnerPage.aspx";
            }
        }

        protected void LoginButton_Click(object sender, EventArgs e)
        {
            string username = ((TextBox)Login1.FindControl("Username")).Text;
            //if (((CheckBox)CreateUserWizardStep1.ContentTemplateContainer.FindControl("RenterCB")).Checked)
            if (Roles.IsUserInRole(username, "RenterRole"))
            {
                Login1.DestinationPageUrl = "~/RenterPage.aspx";
            }
            //else if (((CheckBox)CreateUserWizardStep1.ContentTemplateContainer.FindControl("OwnerCB")).Checked)
            else if (Roles.IsUserInRole(username, "OwnerRole"))
            {
                Login1.DestinationPageUrl = "~/OwnerPage.aspx";
            }
        }

        protected void CreateUserWizard1_FinishButtonClick(object sender, WizardNavigationEventArgs e)
        {
            if (Session["userType"].ToString() == "renter")
            {
                Renter renter = new Renter();

                renter.Username = Session["username"].ToString();
                renter.Name = Session["name"].ToString();
                renter.Password = Session["password"].ToString();
                renter.Phone = Session["phone"].ToString();
                renter.Mail = Session["mail"].ToString();
                renter.Description = Session["description"].ToString();

                renter.CollegeName = ((TextBox)CreateUserWizard1.ActiveStep.Controls[0].FindControl("CollegeName")).Text;
                renter.Age = Int32.Parse(((TextBox)CreateUserWizard1.ActiveStep.Controls[0].FindControl("Age")).Text);
                if (((CheckBox)CreateUserWizard1.ActiveStep.Controls[0].FindControl("ReligiousCB")).Checked)
                {
                    renter.Religious = 1;
                }
                else
                {
                    renter.Religious = 0;
                }

                frontend.NewRenter(renter);

                if (!Roles.RoleExists("RenterRole"))
                {
                    Roles.CreateRole("RenterRole");
                }
                Roles.AddUserToRole(renter.Username, "RenterRole");

                //if (userType == "agent")
                //{
                //    Agent agent = new Agent();
                //    agent.Username = ((TextBox)CreateUserWizardStep1.ContentTemplateContainer.FindControl("UserNameAgent")).Text;
                //    agent.Name = ((TextBox)CreateUserWizardStep1.ContentTemplateContainer.FindControl("NameAgent")).Text;
                //    agent.Password = ((TextBox)CreateUserWizardStep1.ContentTemplateContainer.FindControl("PasswordAgent")).Text;
                //    agent.Phone = ((TextBox)CreateUserWizardStep1.ContentTemplateContainer.FindControl("PhoneAgent")).Text;
                //    agent.Mail = ((TextBox)CreateUserWizardStep1.ContentTemplateContainer.FindControl("EmailAgent")).Text;
                //    agent.Description = ((TextBox)CreateUserWizardStep1.ContentTemplateContainer.FindControl("DescriptionAgent")).Text;
                //    agent.AgencyPercentage = Int32.Parse(((TextBox)CreateUserWizardStep1.ContentTemplateContainer.FindControl("AgencyPercentage")).Text);

                //    frontend.NewAgent(agent);

                //    if (!Roles.RoleExists("AgentRole"))
                //    {
                //        Roles.CreateRole("AgentRole");
                //    }
                //    Roles.AddUserToRole(renter.Username, "AgentRole");
                //}

               
            }
        }
    }
}