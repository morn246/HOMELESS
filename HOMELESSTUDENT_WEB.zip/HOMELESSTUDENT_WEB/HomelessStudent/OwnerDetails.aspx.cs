﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HomelessStudentBE;
using BLFrontend;

namespace HomelessStudent
{
    public partial class OwnerDetails : System.Web.UI.Page
    {
        IBLFrontend frontend = new BLFrontend.Frontend();

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void updateButton_Click(object sender, EventArgs e)
        {
            Owner ownerToUpdate = new Owner();
            ownerToUpdate.Username = Request.Form["username"];
            ownerToUpdate.Name = Request.Form["name"];
            ownerToUpdate.Password = Request.Form["password"];
            ownerToUpdate.Phone = Request.Form["phone"];
            ownerToUpdate.Mail = Request.Form["mail"];
            ownerToUpdate.Description = Request.Form["onMyself"];

            frontend.UpdateOwner(ownerToUpdate);

        }
    }
}