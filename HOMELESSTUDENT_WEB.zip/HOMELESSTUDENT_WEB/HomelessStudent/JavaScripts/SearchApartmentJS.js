﻿function fromPriceTextFocus()
{
    document.getElementById('<%=fromPriceTextBox.ClientID%>').value = '';
}

function fromPriceTextSearch() {

    if (document.getElementById('<%=fromPriceTextBox.ClientID%>').value == '')
        document.getElementById('<%=fromPriceTextBox.ClientID%>').value = 'ממחיר';
}

function toPriceTextFocus() {
    document.getElementById('<%=toPriceTextBox.ClientID%>').value = '';
}

function toPriceTextSearch() {

    if (document.getElementById('<%=toPriceTextBox.ClientID%>').value == '')
        document.getElementById('<%=toPriceTextBox.ClientID%>').value = 'עד מחיר';
}